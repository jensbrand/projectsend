# Security Policy

## Reporting a Vulnerability

Please report security issues to contact@projectsend.org

Thanks!
