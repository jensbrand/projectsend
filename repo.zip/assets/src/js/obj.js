(function () {
    'use strict';
    
    window.admin = {
        parts: {},
        pages: {}
    };
})();